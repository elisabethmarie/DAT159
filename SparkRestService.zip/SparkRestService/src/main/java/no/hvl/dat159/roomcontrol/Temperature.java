package no.hvl.dat159.roomcontrol;

public class Temperature {

	double temperature;

	public Temperature () {
		this.temperature = 0.0;
	}
	
	public double getTemperature() {
		return temperature;
	}

	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}
	
	
}