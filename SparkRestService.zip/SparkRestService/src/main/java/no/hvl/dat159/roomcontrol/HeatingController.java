package no.hvl.dat159.roomcontrol;

public class HeatingController {
	int status = 1;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

}
